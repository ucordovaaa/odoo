# Copyright 2020 KteK <https://www.KteK.co.ke>
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl).

from . import models
from .hooks import uninstall_hook

