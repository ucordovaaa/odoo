.. image:: https://img.shields.io/badge/licence-LGPL--3-blue.svg
   :target: https://www.gnu.org/licenses/agpl
   :alt: License: LGPL-3

Web Hierarchy
=============
Adds hierarchical view of parent-child relationships
among records.

Usage
=====
Add *<hierarchy>* tag and within the fields define two fields
*parent (type:many2one)* and *name (type : Char)*. See below
sample.

.. code-block:: xml

    <record id="view_locations_hierarchy" model="ir.ui.view">
            <field name="name">stock.location.hierarchy</field>
            <field name="model">stock.location</field>
            <field name="arch" type="xml">
                <hierarchy>
                    <field name="location_id"
                           options="{'parent': 'location_id'}"/>
                    <field name="name" options="{'desc': 'name'}"/>
                </hierarchy>
            </field>
    </record>

    <record id="stock.action_location_form" model="ir.actions.act_window">
        <field name="view_mode">tree,hierarchy,form</field>
    </record>

Icon
*****
Main module icon is licensed under
`Hierarchy Icon Png #322855 <https://icon-library.net/icon/hierarchy-icon-png-8.html>`__