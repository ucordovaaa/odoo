# -*- coding: utf-8 -*-
# License AGPL-3

def uninstall_hook(cr, registry):
    cr.execute("UPDATE ir_act_window "
               "SET view_mode=replace(view_mode, ',hierarchy', '')"
               "WHERE view_mode LIKE '%,hierarchy%';")
    cr.execute("UPDATE ir_act_window "
               "SET view_mode=replace(view_mode, 'hierarchy,', '')"
               "WHERE view_mode LIKE '%hierarchy,%';")
    cr.execute("DELETE FROM ir_act_window WHERE view_mode = 'hierarchy';")
