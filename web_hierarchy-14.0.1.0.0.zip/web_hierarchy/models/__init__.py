# Copyright 2020 KteK <https://www.KteK.co.ke>
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl).

from . import ir_ui_view
from . import ir_actions_act_window_view
