odoo.define("web_hierarchy.ViewRegistry", function(require){
    "use strict";

    var viewRegistry = require('web.view_registry');
    var HierarchyView = require('web_hierarchy.View');

    viewRegistry.add('hierarchy', HierarchyView);
});