odoo.define('web_hierarchy.Controller', function(require){
    "use strict";

    var BasicController = require('web.BasicController');
    var Dialog = require('web.Dialog');
    var core = require('web.core');

    var qweb = core.qweb;
    var _t = core._t;

    var HierarchyController = BasicController.extend({
        custom_events: _.extend({}, BasicController.prototype.custom_events, {
        add_record: '_onAddRecord',
        // button_clicked: '_onButtonClicked',
        // edit_line: '_onEditLine',
        // save_line: '_onSaveLine',
        // resequence: '_onResequence',
        // selection_changed: '_onSelectionChanged',
        // toggle_column_order: '_onToggleColumnOrder',
        // toggle_group: '_onToggleGroup',
        // navigation_move: '_onNavigationMove',
    }),
        start: function () {
            this.$el.addClass('o_hierarchy_view');
            return this._super();
        },
       // /**
       //   * @override
       //   */
       //  update: function (params, options) {
       //      var res = this._super.apply(this, arguments);
       //      if (_.isEmpty(params)){
       //          return res;
       //      }
       //      var defaults = _.defaults({}, options, {
       //          adjust_window: true
       //      });
       //      var self = this;
       //      var domains = params.domain;
       //      var contexts = params.context;
       //      var group_bys = params.groupBy;
       //      this.last_domains = domains;
       //      this.last_contexts = contexts;
       //      // select the group by
       //      var n_group_bys = [];
       //      if (this.renderer.arch.attrs.default_group_by) {
       //          n_group_bys = this.renderer.arch.attrs.default_group_by.split(',');
       //      }
       //      if (group_bys.length) {
       //          n_group_bys = group_bys;
       //      }
       //      this.renderer.last_group_bys = n_group_bys;
       //      this.renderer.last_domains = domains;
       //
       //      var fields = this.renderer.fieldNames;
       //      fields = _.uniq(fields.concat(n_group_bys));
       //      return $.when(
       //          res,
       //          self._rpc({
       //              model: self.model.modelName,
       //              method: 'search_read',
       //              kwargs: {
       //                  fields: fields,
       //                  domain: domains,
       //              },
       //              context: self.getSession().user_context,
       //          }).then(function (data) {
       //              return self.renderer.on_data_loaded(data, n_group_bys, defaults.adjust_window);
       //          })
       //      );
       //  },
        _onAddRecord: function (event) {
            event.stopPropagation();
            if (this.activeActions.create) {
                this._addRecord();
            }
            else if (event.data.onFail) {
                event.data.onFail();
            }
            },

        renderButtons: function ($node) {
            if (this.hasButtons) {
                this.$buttons = $(
                    qweb.render('HierarchyView.buttons', {
                        widget: this,
                    })
                );
                this.$buttons.on('click', 'button.o-hierarchy-button-new',
                    this._onButtonNew.bind(this));
                this.$buttons.on('click', 'button.btn-fullscreen',
                    this._onToggleFullScreenView.bind(this));
                this.$buttons.on('click', '.o_hierarchy_view_op_list',
                    this._onChangeViewDirection.bind(this));
                this.$buttons.on('click', '.export-btn-list',
                    this._onClickExportView.bind(this));
                this.$buttons.on('change', 'input[name="can_zoom"]',
                    this._onClickEnableZoom.bind(this));
                this.$buttons.on('change', 'input[name="can_drag"]',
                    this._onClickEnableDrag.bind(this));
                this.$buttons.on('click', 'button.btn-info-tips',
                    this._onClickShowTips.bind(this));
                this.$buttons.appendTo($node);
            }
        },
        _onClickShowTips: function () {
            var self = this;
            var tips_dialog = new Dialog(self, {
                size: 'small',
                dialogClass: 'tips-window',
                title: 'Tips',
                $content: qweb.render('HierarchyTips', {
                        widget: this,
                    }),
                buttons: [{
                    text: _t("Close"),
                    classes : "btn-danger",
                    click: function () {
                        self.do_notify("Info", "Hope tips were useful");
                    },
                    close: true,
                }],
            }).open();
        },
        // Enables zoom of view
        _onClickEnableZoom: function () {
            var self = this;
            var can_zoom = $("input[name='can_zoom']:checked").val();
            if (can_zoom == 'zoom') {
                self.renderer.can_zoom = true;
                self.do_notify("Success", "Mouse Zoom Enabled");
            }
            else {
                self.renderer.can_zoom = false;
                self.renderer.zoomOutLimit = 0.5;
                self.renderer.zoomInLimit = 7;
                self.do_notify("Success", "Mouse Zoom disabled");
            }
            this.renderer._render();
        },
        // Enables drag of hierarchy view
        _onClickEnableDrag: function () {
            var self = this;
            var can_drag = $("input[name='can_drag']:checked").val();
            if (can_drag == 'drag') {
                self.renderer.can_drag = true;
                self.do_notify("Success", "Drag Enabled");
            }
            else {
                self.renderer.can_drag = false;
                self.do_notify("Success", "Drag Disabled");
            }
            this.renderer._render();
        },
        // Create new record in form view
        _onButtonNew: function (event) {
            event.stopPropagation();
            this.trigger_up('switch_view', {
                view_type: 'form',
                res_id: undefined,
            });
        },

        // Change Root View
        _onChangeViewDirection: function (event) {
            var val = event.target.id;
            this.renderer.view_direction = val;
            this.renderer._render();
            this.do_notify("Success", "View changed successfully");
        },

        // Export hierarchy to png or pdf
        _onClickExportView: function (event) {
            var val = event.target.id;
            var no_bck = $("input[name='no_bck']:checked").val();
            var zoom = this.renderer.can_zoom;
            var drag = this.renderer.can_drag;
            var view_d = this.renderer.view_direction;
            if (val == 'export_png') {
                var ext = 'png';
                if (no_bck == 'no_bck') this.renderer._exportHierarchyView(
                    view_d, ext, zoom, drag, no_bck=true);
                else this.renderer._exportHierarchyView(
                    view_d, ext, zoom, drag);
            }
            if (val == 'export_pdf') {
                var ext = 'pdf';
                if (no_bck == 'no_bck') this.renderer._exportHierarchyView(
                    view_d, ext, zoom, drag, no_bck=true);
                else this.renderer._exportHierarchyView(
                    view_d, ext, zoom, drag);
            }
        },

        // Toggle fullscreen
        _onToggleFullScreenView: function (event) {
            $('.o_main_navbar').toggle();
        },

        buttons_template: 'HierarchyView.buttons',
    });

    return HierarchyController;

});