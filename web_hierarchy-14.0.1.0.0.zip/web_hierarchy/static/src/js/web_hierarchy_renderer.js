odoo.define('web_hierarchy.Renderer', function(require){
    "use strict";

    var BasicRenderer = require('web.BasicRenderer');
    var Dialog = require('web.Dialog');
    var core = require('web.core');

    var qweb = core.qweb;
    var _t = core._t;

    var HierarchyRenderer = BasicRenderer.extend({
        template: 'HierarchyView.HierarchyView',
        events: _.extend({}, BasicRenderer.prototype.events, {
            'click div#main_node_1 div.title': '_onClickOpenColorPalette',
            'click .node': '_onClickOpenFormView',
        }),
        init: function (parent, state, params) {
            this._super.apply(this, arguments);
            this.chained_nodes = [];
            this.root_name = params.root_name;
            this.view_direction = 'l2r';
            this.can_zoom = false;
            this.can_drag = false;
            this.can_export = false;
            this.export_ext = "";
            this.new_node_bg = "rgba(217,83,79,0.8)";
        },
        start: function () {
            var self = this
            var parent = this.arch.children.find((x)=> x.attrs.options &&
                JSON.parse(x.attrs.options.replace(/'/g, '"')).parent) || false;
            var desc = this.arch.children.find((x)=> x.attrs.options &&
                JSON.parse(x.attrs.options.replace(/'/g, '"')).desc) || false;
            if (this._checkParentField(parent.attrs.name)){
                self.parent_field = parent;
            }
            if (this._checkDescField(desc.attrs.name)) {
                self.desc_field = desc;
            }
            this.$hierarchy = this.$el.find(".o_hierarchy_widget");
            this._super.apply(this, self);
        },
        _checkDescField: function (desc='') {
            var field = this.state.fields[desc]
            if (field) {
                if (field.type == 'char' || field.type == 'many2one')
                    return true;
            }
            else {
                 var error = "Desc field MUST be added to view and should" +
                     " be of type 'char'";
                 var options = {
                     title: 'Error',
                     dialogClass: 'danger-alert danger-alert-issue'
                 };
                 Dialog.alert(self, error, options);
                 return false;
            }
        },
        _checkParentField: function (parent='') {
            var field = this.state.fields[parent]
            if (field && field.type == 'many2one') return true;
            else {
                 var error = "Parent field MUST be added to view and should" +
                     " be of type 'many2one'";
                 var options = {
                     title: 'Error',
                     dialogClass: 'danger-alert danger-alert-issue'
                 };
                 Dialog.alert(self, error, options);
                 return false;
            }
        },
        _exportHierarchyView: function (view_direction="", ext="",
                                        can_zoom=false, can_drag=false,
                                        no_bck=false) {   var values = this.state.data;
            var root_node = this._treeNodeTransversal(values);
            if (!this.orgchart) {
                return this.$hierarchy.orgchart({
                    'data': root_node,
                    'nodeContent': 'title',
                    'pan': can_drag, //drag tree
                    'zoom': can_zoom, //zoom in and out
                    'direction': view_direction,
                    'chartClass': 'o_hierarchy_widget'
                }).export('chart', ext, no_bck);
            }
            else {
                this.orgchart.export('chart', ext, no_bck);
            }
        },
        _hierarchyDesign: function (view_direction="", ext="", can_zoom=false,
                                    can_drag=false, can_export=false) {
            var self = this;
            var values = this.state.data;
            var root_node = this._treeNodeTransversal(values);
            this.orgchart = this.$hierarchy.orgchart({
                'data' : root_node,
                'nodeContent': 'title',
                'parentNodeSymbol': 'fa_tree_node',
                'pan': can_drag, //drag tree
                'zoom': can_zoom, //zoom in and out
                'exportButton': can_export,
                'exportFileextension': ext,
                'exportFilename': 'chart',
                'direction': view_direction,
                'chartClass': 'o_hierarchy_widget',
                'animation': {
                    nodeAnimation: "easeOutBounce",
                    nodeSpeed: 700,
                    connectorsAnimation: "bounce",
                    connectorsSpeed: 700
                }
            });
            this.$hierarchy.find('.title').css(
                                {'background': self.new_node_bg})
            // Responsive design
            // $(window).resize(function() {
            //     var width = $(window).width();
            //     if(width > 576) {
            //         self.orgchart.init({'verticalLevel': undefined});
            //     } else {
            //         self.orgchart.init({'verticalLevel': 2});
            //     }
            // });
        },
        _renderView: function () {
            var self = this;
            return $.when().then(function () {
                self.$hierarchy.empty(); // clear existing,... reload view.
                self._hierarchyDesign(
                    self.view_direction,
                    self.export_ext,
                    self.can_zoom,
                    self.can_drag,
                    self.can_export
                    );
                  self.$hierarchy.find('.symbol').removeClass('symbol');
            });
        },
        _buildUnorderedNodes: function(values=[]) {
            var self = this;
            var unordered_nodes = [];
            if (values.length != 0) {
                _.each(values, function(val){
                    unordered_nodes.push(self._buildNodeValues(val))
                });
            }
            return unordered_nodes;
        },
        _buildNodeValues: function (node) {
            var self = this;
            var parent_id = '';
            if (node.data.parent_id && node.data.parent_id.data.id) {
                parent_id = node.data.parent_id.data.id.toString() || '';
            }
            return {
                'id': node.data.id.toString(),
                'data-parent': parent_id,
                'name': self._getFieldData(self._getAbsQuery('parent'),
                    node),
                'title': self._getFieldData(self._getAbsQuery('desc'),
                    node),
                'children': []
            };
       },
        _treeNodeTransversal: function (values=[]) {
            var root = this._getDefaultParentNode();
            var nodes = [];
            var values = this.state.data;
            var unordered_lst = this._buildUnorderedNodes(values);
            var val_ids = unordered_lst.map((x)=>x['id']);
            /*
            Below algorithm concept derived from Nick Scialli
            https://typeofnan.dev/an-easy-way-to-build-a-tree-with-object-references/
            Complexity is O(n)
            */
            unordered_lst.forEach(element => {
                // Handle the root elements
                if (element['data-parent'] === '') {
                    nodes.push(element);
                    return;
                }
                // Assign child to parent element
                const parent = unordered_lst.find((val)=> val['id'] ==
                    element['data-parent']);
                parent['children'] = [...(parent['children'] || []),
                    element];
            });
            root['children'] = nodes;
            return root;
        },
        _getAbsQuery: function (field='') {
            var attrs = this.arch.children.filter((x)=> x.attrs.options);
            var vals = attrs.map((x)=>JSON.parse(
                x.attrs.options.replace(/\'/g, '"')));
            var result = vals.find((x)=> x[field]) || false;
            if (result) {
                return result[field];
            }
            else return false;
        },
        _getFieldData: function(field, holder={}) {
            var self = this;
            if (holder.fields[field]) {
                 if (holder.fields[field]['type'] == "many2one" && holder.data[field].data) {
                     if (holder.data[field].data.hasOwnProperty('display_name'))
                         return holder.data[field].data['display_name'];
                     else {
                         var error = "Please define a 'name' for many2one field " +
                             field + ".";
                         var options = {
                             title: 'Name Warning',
                             dialogClass: 'danger-alert danger-alert-issue'
                         };
                         Dialog.alert(self, error, options);
                         return holder.data[field].data
                     }
                 }
                 else
                     return holder.data[field] || '';
            }
            else {
                return "";
            }
        },
        _getDefaultParentNode: function () {
            return {
                id: "main_node_1",
                name: this.root_name,
                title: this.root_name + " Hierarchy",
                children: []
            }
        },
        _onClickOpenFormView: function(event) {
            event.stopPropagation();
            var self = this;
            var res_id = event.currentTarget.id;
            var model = this.state.model;
            var mode = 'edit' || this.mode;
            var context = this.state.context;
            if (/^\d+$/.test(res_id)) {
                var id = parseInt(res_id);
                this.trigger_up('switch_view', {
                    view_type: 'form',
                    res_id: id,
                    mode: mode,
                    model: model,
                });
                this.do_notify("Info", "Edit record and click back");
            }
            else {
                context['group_by'] = this.parent_field || false;
                this.do_action({
                    name: self.root_name,
                    type: 'ir.actions.act_window',
                    res_model: model,
                    views: [[false, 'list'], [false, 'form'], [false, 'kanban']],
                    view_type: 'list',
                    view_mode: 'list',
                    target: 'new',
                    context: context,
                });
            }
            },
        _onClickOpenColorPalette: function(event) {
            event.stopPropagation();
            var self = this;
            this.color_palette = new Dialog(self, {
                size: 'small',
                title: 'Node Color',
                $content: qweb.render('ColorPalette', {
                        widget: this,
                }),
                buttons: [{
                    text: _t("Change"),
                    classes : "btn-success",
                    click: function () {
                        self.new_node_bg = self.color_palette.$el.val();
                        if (self.new_node_bg){
                            self.$hierarchy.find('.title').css(
                                {'background': self.new_node_bg});
                            self.do_notify("success", "Nodes color updated!");
                        }
                    },
                    close: true,
                }],
            }).open();
            this.color_palette.opened().then(function () {
                self.node_bg = self.$hierarchy.find('div#main_node_1 .title')
                    .css('background') || '#d9534fc9';
                self.color_palette.$el.spectrum({
                    color: self.node_bg,
                    type: "component"
                });
            });
        }
    });

    return HierarchyRenderer;
});