odoo.define('web_hierarchy.View', function(require){
    "use strict";

    var HierarchyController = require('web_hierarchy.Controller');
    var HierarchyRenderer = require('web_hierarchy.Renderer');
    var BasicView = require('web.BasicView');
    var core = require('web.core');

    var _lt = core._lt;

    var HierarchyView = BasicView.extend({
        accesskey: "h",
        display_name: _lt('Hierarchy'),
        icon: 'fa-sitemap',
        searchable: false,
       config: _.extend({}, BasicView.prototype.config, {
            Controller: HierarchyController,
            Renderer: HierarchyRenderer,
        }),
        mobile_friendly: true,
        viewType: 'hierarchy',
        groupable: false,
        init: function (viewInfo, params) {
            this._super.apply(this, arguments);
            this.rendererParams.root_name = params.action.display_name || 'Tree';
        }
    });
    return HierarchyView;
});