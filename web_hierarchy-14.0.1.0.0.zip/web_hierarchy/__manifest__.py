# Copyright 2020 KteK <https://www.KteK.co.ke>
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl).

{
    'name': 'Web Hierarchy',
    'version': '14.0.1.0.0',
    'category': 'Extra Tools',
    'author': "Kevin Kamau",
    'summary': "This modules adds hierarchical view to Odoo records.",
    'license': 'LGPL-3',
    'price': 70.00,
    'currency': 'USD',
    'depends': [
        'web'
    ],
    'data': [
        'views/web_backend.xml'
    ],
    'images': ['images/main_screenshot.png'],
    'qweb': ['static/src/xml/*.xml'],
    'installable': True,
    'uninstall_hook': 'uninstall_hook',
}
