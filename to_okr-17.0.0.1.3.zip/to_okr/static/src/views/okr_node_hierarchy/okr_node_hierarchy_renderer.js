/** @odoo-module **/

import { HierarchyRenderer } from "@web_hierarchy/hierarchy_renderer";
import { OkrNodeHierarchyCard } from "./okr_node_hierarchy_card";

export class OkrNodeHierarchyRenderer extends HierarchyRenderer {
	static template = "web_hierarchy.HierarchyRenderer";
	static components = {
		...HierarchyRenderer.components,
		HierarchyCard: OkrNodeHierarchyCard,
	};
}
