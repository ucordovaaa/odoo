/** @odoo-module */

import { HierarchyCard } from "@web_hierarchy/hierarchy_card";

export class OkrNodeHierarchyCard extends HierarchyCard {
	static template = "to_okr.OkrNodeHierarchyCard";
}
