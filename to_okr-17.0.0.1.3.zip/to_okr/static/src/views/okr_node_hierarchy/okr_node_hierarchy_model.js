/** @odoo-module **/

import { HierarchyModel } from "@web_hierarchy/hierarchy_model";

export class OkrNodeHierarchyModel extends HierarchyModel {

	async fetchManager () {
		if (this.resModel === 'okr.node') {
			this.config.context.js_rpc_call_from_okr_node_hierarchy = true;
		};
		return super.fetchManager(...arguments);
	};

};
