/** @odoo-module **/

import { registry } from "@web/core/registry";
import { hierarchyView } from "@web_hierarchy/hierarchy_view";
import { OkrNodeHierarchyRenderer } from "./okr_node_hierarchy_renderer";
import { OkrNodeHierarchyModel } from "./okr_node_hierarchy_model";

export const OkrNodeHierarchyView = {
	...hierarchyView,
	Model: OkrNodeHierarchyModel,
	Renderer: OkrNodeHierarchyRenderer,
};

registry.category("views").add("okr_node_hierarchy", OkrNodeHierarchyView);
